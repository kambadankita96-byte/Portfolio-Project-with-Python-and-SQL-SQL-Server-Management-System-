```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import mysql.connector

```


```python
import pyodbc

conn = pyodbc.connect(
    'DRIVER={ODBC Driver 17 for SQL Server};'
    'SERVER=DESKTOP-7BNSLSA\\SQLEXPRESS;'
    'DATABASE=master;'
    'Trusted_Connection=yes;'
)
cur = conn.cursor()
```

# List all unique cities where customers are located.



```python
query = "SELECT customer_city FROM customers"
cur.execute(query)
data = cur.fetchall()
data
```




    [('franca',),
     ('sao bernardo do campo',),
     ('sao paulo',),
     ('mogi das cruzes',),
     ('campinas',),
     ('jaragua do sul',),
     ('sao paulo',),
     ('timoteo',),
     ('curitiba',),
     ('belo horizonte',),
     ('montes claros',),
     ('rio de janeiro',),
     ('lencois paulista',),
     ('sao paulo',),
     ('caxias do sul',),
     ('piracicaba',),
     ('rio de janeiro',),
     ('guarulhos',),
     ('sao paulo',),
     ('pacaja',),
     ('florianopolis',),
     ('aparecida de goiania',),
     ('sao paulo',),
     ('curitiba',),
     ('sao paulo',),
     ('santo andre',),
     ('goiania',),
     ('sao paulo',),
     ('cachoeiro de itapemirim',),
     ('sao paulo',),
     ('sao jose dos campos',),
     ('sao roque',),
     ('camacari',),
     ('resende',),
     ('curitiba',),
     ('sumare',),
     ('guarulhos',),
     ('novo hamburgo',),
     ('sao luis',),
     ('sao jose',),
     ('guarulhos',),
     ('santa barbara',),
     ('sao paulo',),
     ('guarulhos',),
     ('ribeirao preto',),
     ('belo horizonte',),
     ('ituiutaba',),
     ('taquarituba',),
     ('sao jose dos pinhais',),
     ('jaragua do sul',),
     ('sao paulo',),
     ('montes claros',),
     ('barrinha',),
     ('rio de janeiro',),
     ('parati',),
     ('dourados',),
     ('sao paulo',),
     ('trindade',),
     ('cascavel',),
     ('fortaleza',),
     ('brasilia',),
     ('sao paulo',),
     ('pelotas',),
     ('porto alegre',),
     ('rio de janeiro',),
     ('salto',),
     ('belo horizonte',),
     ('jundiai',),
     ('cachoeiro de itapemirim',),
     ('cacapava',),
     ('fortaleza',),
     ('sao vicente',),
     ('uberlandia',),
     ('botelhos',),
     ('sao goncalo',),
     ('sao paulo',),
     ('sao paulo',),
     ('araucaria',),
     ('sao vicente',),
     ('nova iguacu',),
     ('sao paulo',),
     ('areia branca',),
     ('sao paulo',),
     ('campos dos goytacazes',),
     ('sao carlos',),
     ('sao paulo',),
     ('itajuba',),
     ('porto alegre',),
     ('sao bernardo do campo',),
     ('salto',),
     ('cruz das almas',),
     ('vassouras',),
     ('feira de santana',),
     ('sao paulo',),
     ('brasilia',),
     ('sao carlos',),
     ('sao paulo',),
     ('sao paulo',),
     ('niteroi',),
     ('sao luis',),
     ('sao paulo',),
     ('sao paulo',),
     ('jaragua do sul',),
     ('sobral',),
     ('divinopolis',),
     ('mogi das cruzes',),
     ('brasilia',),
     ('sao paulo',),
     ('sao paulo',),
     ('paraiba do sul',),
     ('paulista',),
     ('sao paulo',),
     ('carapicuiba',),
     ('sao paulo',),
     ('bom principio',),
     ('sao paulo',),
     ('astolfo dutra',),
     ('curitiba',),
     ('belo horizonte',),
     ('marialva',),
     ('sao paulo',),
     ('sao jose do rio preto',),
     ('cabo frio',),
     ('contagem',),
     ('uberlandia',),
     ('cafeara',),
     ('porto alegre',),
     ('sao joaquim da barra',),
     ('foz do iguacu',),
     ('belo horizonte',),
     ('sao bernardo do campo',),
     ('sao goncalo',),
     ('suzano',),
     ('guarulhos',),
     ('timbo',),
     ('camboriu',),
     ('nova bassano',),
     ('rio grande',),
     ('brasilia',),
     ('braganca paulista',),
     ('barra do garcas',),
     ('sao paulo',),
     ('embu',),
     ('sao bernardo do campo',),
     ('brasilia',),
     ('urussanga',),
     ('silvianopolis',),
     ('sao paulo',),
     ('gameleiras',),
     ('belem',),
     ('pocos de caldas',),
     ('contagem',),
     ('santos',),
     ('piracaia',),
     ('rio de janeiro',),
     ('santos',),
     ('sinop',),
     ('guaruja',),
     ('barueri',),
     ('sao paulo',),
     ('feliz',),
     ('sao paulo',),
     ('belo horizonte',),
     ('jambeiro',),
     ('sao jose do rio preto',),
     ('ipatinga',),
     ('tupa',),
     ('sao paulo',),
     ('brasilia',),
     ('blumenau',),
     ('moncoes',),
     ('rio de janeiro',),
     ('sao paulo',),
     ('balneario camboriu',),
     ('rio de janeiro',),
     ('sao paulo',),
     ('vargem grande',),
     ('rio brilhante',),
     ('eugenopolis',),
     ('belem',),
     ('sao jose do rio preto',),
     ('paulinia',),
     ('sao paulo',),
     ('jundiai',),
     ('sao paulo',),
     ('santo andre',),
     ('sao jose dos campos',),
     ('rio de janeiro',),
     ('campinas',),
     ('belo horizonte',),
     ('apucarana',),
     ('recife',),
     ('osasco',),
     ('valinhos',),
     ('santo andre',),
     ('manaus',),
     ('cidreira',),
     ('rio de janeiro',),
     ('santiago',),
     ('sao paulo',),
     ('sao sepe',),
     ('alta floresta',),
     ('guarulhos',),
     ('jaboatao dos guararapes',),
     ('sao paulo',),
     ('ibatiba',),
     ('hortolandia',),
     ('sao paulo',),
     ('cotia',),
     ('macae',),
     ('saudades',),
     ('rio de janeiro',),
     ('macapa',),
     ('salto de pirapora',),
     ('taboao da serra',),
     ('bom jesus',),
     ('caxias do sul',),
     ('uberlandia',),
     ('santa cruz do rio pardo',),
     ('diadema',),
     ('santa ines',),
     ('rio de janeiro',),
     ('serrinha',),
     ('votorantim',),
     ('hortolandia',),
     ('itatiaia',),
     ('duque de caxias',),
     ('varre-sai',),
     ('rio de janeiro',),
     ('caxias do sul',),
     ('rio de janeiro',),
     ('vila velha',),
     ('campinas',),
     ('mangaratiba',),
     ('atibaia',),
     ('sao paulo',),
     ('salvador',),
     ('maceio',),
     ('porto alegre',),
     ('rio de janeiro',),
     ('birigui',),
     ('franca',),
     ('petropolis',),
     ('niteroi',),
     ('porto alegre',),
     ('sao pedro',),
     ('jaguariaiva',),
     ('rio de janeiro',),
     ('franco da rocha',),
     ('sao paulo',),
     ('brasilia',),
     ('cacapava',),
     ('jundiai',),
     ('salvador',),
     ('pindamonhangaba',),
     ('irati',),
     ('ribeira',),
     ('ipatinga',),
     ('sao paulo',),
     ('barbacena',),
     ('limoeiro',),
     ('espigao do oeste',),
     ('belford roxo',),
     ('sao jose dos campos',),
     ('brasilia',),
     ('coronel fabriciano',),
     ('diadema',),
     ('brasilia',),
     ('brasilia',),
     ('itanhaem',),
     ('goiania',),
     ('bebedouro',),
     ('americana',),
     ('salvador',),
     ('uba',),
     ('arapongas',),
     ('vinhedo',),
     ('itajai',),
     ('dourados',),
     ('bauru',),
     ('pradopolis',),
     ('sao paulo',),
     ('aripuana',),
     ('braganca paulista',),
     ('sao paulo',),
     ('guaratinga',),
     ('sao paulo',),
     ('ponta pora',),
     ('aracatuba',),
     ('volta redonda',),
     ('maringa',),
     ('guarulhos',),
     ('sao paulo',),
     ('sao paulo',),
     ('araraquara',),
     ('matipo',),
     ('niteroi',),
     ('barbacena',),
     ('porto alegre',),
     ('santo antonio da patrulha',),
     ('sao paulo',),
     ('porto alegre',),
     ('barra mansa',),
     ('fortaleza',),
     ('diamantina',),
     ('belo horizonte',),
     ('brasilia',),
     ('maringa',),
     ('salvador',),
     ('sao paulo',),
     ('macae',),
     ('sao paulo',),
     ('mairinque',),
     ('belo horizonte',),
     ('capitao leonidas marques',),
     ('rio de janeiro',),
     ('sao sebastiao do paraiso',),
     ('rio de janeiro',),
     ('petropolis',),
     ('sao paulo',),
     ('sao paulo',),
     ('sao paulo',),
     ('piracicaba',),
     ('belford roxo',),
     ('brasilia',),
     ('goiania',),
     ('rosario do sul',),
     ('itaguai',),
     ('sao paulo',),
     ('guaruja',),
     ('paraopeba',),
     ('santo andre',),
     ('campinas',),
     ('sao paulo',),
     ('rio de janeiro',),
     ('belo horizonte',),
     ('guarapuava',),
     ('crisolita',),
     ('pirai',),
     ('maceio',),
     ('linhares',),
     ('agudos',),
     ('sao paulo',),
     ('sao paulo',),
     ('rio de janeiro',),
     ('sao joao de meriti',),
     ('sao paulo',),
     ('rio de janeiro',),
     ('navegantes',),
     ('pirassununga',),
     ('sao bernardo do campo',),
     ('faxinal dos guedes',),
     ('guarulhos',),
     ('brasilia',),
     ('brasilia',),
     ('criciuma',),
     ('nova venecia',),
     ('passo fundo',),
     ('sao paulo',),
     ('uberlandia',),
     ('carapicuiba',),
     ('rio de janeiro',),
     ('ibia',),
     ('aparecida de goiania',),
     ('sao paulo',),
     ('santos',),
     ('manhuacu',),
     ('sumare',),
     ('altamira',),
     ('goiania',),
     ('rio de janeiro',),
     ('sao jose',),
     ('sao paulo',),
     ('aperibe',),
     ('sao vicente',),
     ('aracatuba',),
     ('cuiaba',),
     ('canoas',),
     ('contagem',),
     ('belo horizonte',),
     ('sao paulo',),
     ('belo horizonte',),
     ('cubatao',),
     ('maringa',),
     ('sao paulo',),
     ('campo limpo paulista',),
     ('cambe',),
     ('itaquaquecetuba',),
     ('sao caetano do sul',),
     ('sao jose dos campos',),
     ('sao paulo',),
     ('sao paulo',),
     ('montes claros',),
     ('salvador',),
     ('belo horizonte',),
     ('niteroi',),
     ('rio de janeiro',),
     ('guarulhos',),
     ('sao paulo',),
     ('sao goncalo do rio abaixo',),
     ('rolandia',),
     ('tres coracoes',),
     ('cacapava do sul',),
     ('sao paulo',),
     ('sao paulo',),
     ('sao paulo',),
     ('ribeirao preto',),
     ('sao goncalo',),
     ('sao joao nepomuceno',),
     ('cotia',),
     ('niteroi',),
     ('canoas',),
     ('rio de janeiro',),
     ('goiania',),
     ('leme',),
     ('araras',),
     ('jundiai',),
     ('cortes',),
     ('ipatinga',),
     ('sao paulo',),
     ('ribeirao preto',),
     ('brusque',),
     ('fortaleza',),
     ('montenegro',),
     ('itaberai',),
     ('pindamonhangaba',),
     ('brasilia',),
     ('santa rosa de viterbo',),
     ('agua fria de goias',),
     ('santos',),
     ('marau',),
     ('curvelo',),
     ('niteroi',),
     ('juiz de fora',),
     ('uberlandia',),
     ('mogi-guacu',),
     ('niteroi',),
     ('sao paulo',),
     ('sao paulo',),
     ('sao paulo',),
     ('sao paulo',),
     ('belo horizonte',),
     ('osasco',),
     ('sao paulo',),
     ('guaratingueta',),
     ('sao bernardo do campo',),
     ('paranagua',),
     ('lins',),
     ('sao paulo',),
     ('campo bom',),
     ('sertaozinho',),
     ('sao paulo',),
     ('tres lagoas',),
     ('taboao da serra',),
     ('contagem',),
     ('niteroi',),
     ('santo andre',),
     ('sao paulo',),
     ('jau',),
     ('curitiba',),
     ('montenegro',),
     ('sao jose',),
     ('campos de julio',),
     ('saquarema',),
     ('sao caetano do sul',),
     ('artur nogueira',),
     ('uaua',),
     ('sao paulo',),
     ('jandira',),
     ('belo horizonte',),
     ('sao paulo',),
     ('sao paulo',),
     ('valinhos',),
     ('concordia',),
     ('nova friburgo',),
     ('sorocaba',),
     ('rio de janeiro',),
     ('ponte nova',),
     ('araquari',),
     ('sao jose dos campos',),
     ('muriae',),
     ('sao paulo',),
     ('barueri',),
     ('santo andre',),
     ('navegantes',),
     ('nova lima',),
     ('inhumas',),
     ('italva',),
     ('sao paulo',),
     ('tres rios',),
     ('belford roxo',),
     ('santa maria',),
     ('itagiba',),
     ('florianopolis',),
     ('sao paulo',),
     ('paracatu',),
     ('rio de janeiro',),
     ('curitiba',),
     ('rio de janeiro',),
     ('xaxim',),
     ('rio de janeiro',),
     ('santo andre',),
     ('laranjeiras do sul',),
     ('sao paulo',),
     ('sao paulo',),
     ('itapiuna',),
     ('sao paulo',),
     ('guarulhos',),
     ('campinas',),
     ('recife',),
     ('ribeirao preto',),
     ('divinopolis',),
     ('sao paulo',),
     ('piracicaba',),
     ('formosa',),
     ('niteroi',),
     ('florianopolis',),
     ('ponte nova',),
     ('niteroi',),
     ('piracicaba',),
     ('rio brilhante',),
     ('sao paulo',),
     ('sao paulo',),
     ('sao paulo',),
     ('birigui',),
     ('ivoti',),
     ('salvador',),
     ('juazeiro',),
     ('ponta grossa',),
     ('nova venecia',),
     ('campina grande',),
     ('rio de janeiro',),
     ('osasco',),
     ('osasco',),
     ('votorantim',),
     ('sao paulo',),
     ('maua',),
     ('salgueiro',),
     ('sao jose dos campos',),
     ('rio de janeiro',),
     ('lorena',),
     ('sao paulo',),
     ('sao goncalo',),
     ('guaruja',),
     ('nova iguacu',),
     ('sao paulo',),
     ('fortaleza',),
     ('toledo',),
     ('niteroi',),
     ('sao pedro da aldeia',),
     ('curitiba',),
     ('sao bernardo do campo',),
     ('rio de janeiro',),
     ('rio de janeiro',),
     ('vianopolis',),
     ('arapiraca',),
     ('porto seguro',),
     ('volta redonda',),
     ('sao paulo',),
     ('sao paulo',),
     ('curitiba',),
     ('sao goncalo',),
     ('osasco',),
     ('sao paulo',),
     ('nova iguacu',),
     ('barueri',),
     ('ariquemes',),
     ('presidente getulio',),
     ('brasilia',),
     ('belo horizonte',),
     ('rio de janeiro',),
     ('florianopolis',),
     ('rio negro',),
     ('contagem',),
     ('caxias do sul',),
     ('porto alegre',),
     ('fortaleza',),
     ('rio de janeiro',),
     ('santa maria',),
     ('rio de janeiro',),
     ('sao paulo',),
     ('jau',),
     ('recife',),
     ('rio de janeiro',),
     ('ribeirao pires',),
     ('sao jose da coroa grande',),
     ('rio de janeiro',),
     ('agua doce do norte',),
     ('sao bernardo do campo',),
     ('anapolis',),
     ('guararapes',),
     ('petropolis',),
     ('sao paulo',),
     ('suzano',),
     ('farroupilha',),
     ('maua',),
     ('rio de janeiro',),
     ('cacapava',),
     ('almenara',),
     ('rio das ostras',),
     ('gravatai',),
     ('recife',),
     ('brumado',),
     ('sao paulo',),
     ('belo horizonte',),
     ('sao paulo',),
     ('rio de janeiro',),
     ('campos dos goytacazes',),
     ('marilia',),
     ('itabira',),
     ('sorocaba',),
     ('rio de janeiro',),
     ('sao paulo',),
     ('claudia',),
     ('florianopolis',),
     ('rio de janeiro',),
     ('guarulhos',),
     ('sao caetano do sul',),
     ('belo horizonte',),
     ('rio de janeiro',),
     ('sao paulo',),
     ('para de minas',),
     ('niteroi',),
     ('miguelopolis',),
     ('terra roxa',),
     ('paulinia',),
     ('araguari',),
     ('contagem',),
     ('rio de janeiro',),
     ('cacapava',),
     ('lages',),
     ('brasilia',),
     ('rio de janeiro',),
     ('embu das artes',),
     ('saquarema',),
     ('rio de janeiro',),
     ('limeira',),
     ('canoas',),
     ('sao paulo',),
     ('sao jose do rio preto',),
     ('taubate',),
     ('fortaleza',),
     ('santa fe do sul',),
     ('caieiras',),
     ('sao paulo',),
     ('itaguai',),
     ('carangola',),
     ('chapada do norte',),
     ('campinas',),
     ('loanda',),
     ('franca',),
     ('passa tres',),
     ('aracoiaba da serra',),
     ('nova iguacu',),
     ('porto alegre',),
     ('cachoeiro de itapemirim',),
     ('itaborai',),
     ('juiz de fora',),
     ('limeira',),
     ('aperibe',),
     ('vitoria',),
     ('rio de janeiro',),
     ('sao paulo',),
     ('sao bento do sul',),
     ('nova iguacu',),
     ('indaiatuba',),
     ('rio grande',),
     ('caxias do sul',),
     ('boituva',),
     ('teresopolis',),
     ('pinhalzinho',),
     ('petrolina',),
     ('sao paulo',),
     ('natal',),
     ('diadema',),
     ('curitiba',),
     ('sao paulo',),
     ('santo andre',),
     ('sao paulo',),
     ('suzano',),
     ('santa cruz do rio pardo',),
     ('barreiras',),
     ('mogi-guacu',),
     ('sao paulo',),
     ('florianopolis',),
     ('januaria',),
     ('ipiabas',),
     ('firminopolis',),
     ('joinville',),
     ('rio de janeiro',),
     ('barueri',),
     ('mococa',),
     ('belo horizonte',),
     ('sao paulo',),
     ('rio de janeiro',),
     ('vitoria',),
     ('vitoria',),
     ('valenca',),
     ('sao miguel do oeste',),
     ('nova iguacu',),
     ('franca',),
     ('salvador',),
     ('goiania',),
     ('sao paulo',),
     ('rio de janeiro',),
     ('sao bernardo do campo',),
     ('mogi-guacu',),
     ('sao paulo',),
     ('indaiatuba',),
     ('sao paulo',),
     ('sao paulo',),
     ('atibaia',),
     ('montes claros',),
     ('brasilia',),
     ('ponta grossa',),
     ('pirassununga',),
     ('piracicaba',),
     ('jales',),
     ('sao joao de meriti',),
     ('recife',),
     ('sao paulo',),
     ('sao vicente',),
     ('rio formoso',),
     ('belo horizonte',),
     ('rio de janeiro',),
     ('sao paulo',),
     ('rio de janeiro',),
     ('brasilia',),
     ('angra dos reis',),
     ('vitoria',),
     ('brasilia',),
     ('sao paulo',),
     ('alfredo chaves',),
     ('vitoria',),
     ('rio de janeiro',),
     ('sao paulo',),
     ('sao jose dos campos',),
     ('itapetinga',),
     ('sao paulo',),
     ('gurupi',),
     ('belo horizonte',),
     ('cambe',),
     ('jaboatao dos guararapes',),
     ('sao paulo',),
     ('nucleo residencial pilar',),
     ('santos',),
     ('salvador',),
     ('coromandel',),
     ('charqueada',),
     ('osasco',),
     ('itau de minas',),
     ('sao paulo',),
     ('ibiruba',),
     ('bertioga',),
     ('brasilia',),
     ('contagem',),
     ('ipiau',),
     ('limeira',),
     ('sao paulo',),
     ('jau',),
     ('matozinhos',),
     ('volta redonda',),
     ('curitiba',),
     ('teresina',),
     ('sao paulo',),
     ('uberlandia',),
     ('belo horizonte',),
     ('entre rios',),
     ('itajuba',),
     ('campinas',),
     ('jandira',),
     ('sao paulo',),
     ('juina',),
     ('divinopolis',),
     ('porto alegre',),
     ('mairipora',),
     ('rio de janeiro',),
     ('sao paulo',),
     ('teresina',),
     ('marechal candido rondon',),
     ('votorantim',),
     ('sao bernardo do campo',),
     ('sao paulo',),
     ('vitoria',),
     ('franco da rocha',),
     ('belo horizonte',),
     ('cotia',),
     ('avare',),
     ('sao bernardo do campo',),
     ('rio de janeiro',),
     ('aparecida de goiania',),
     ('icem',),
     ('anapolis',),
     ('sao sebastiao',),
     ('sao roque',),
     ('serra',),
     ('mirassol',),
     ('taperuaba',),
     ('montes claros',),
     ('sorocaba',),
     ('sao paulo',),
     ('carapicuiba',),
     ('alfenas',),
     ('santo andre',),
     ('leopoldina',),
     ('brasilia',),
     ('sao joao da boa vista',),
     ('sao paulo',),
     ('sao paulo',),
     ('uba',),
     ('parnamirim',),
     ('guarulhos',),
     ('teixeira de freitas',),
     ('atibaia',),
     ('porto alegre',),
     ('sao paulo',),
     ('joao pessoa',),
     ('chacara',),
     ('rio novo do sul',),
     ('rio de janeiro',),
     ('belo horizonte',),
     ('belo horizonte',),
     ('teresina',),
     ('salto de pirapora',),
     ('sao paulo',),
     ('belford roxo',),
     ('sao paulo',),
     ('guapore',),
     ('rio branco',),
     ('uberlandia',),
     ('ferraz de vasconcelos',),
     ('sao jose dos campos',),
     ('porto alegre',),
     ('sao luis',),
     ('taboao da serra',),
     ('curitiba',),
     ('maringa',),
     ('petrolandia',),
     ('guarulhos',),
     ('niteroi',),
     ('rio de janeiro',),
     ('aparecida de goiania',),
     ('goiania',),
     ('jundiai',),
     ('osasco',),
     ('araruna',),
     ('gravata',),
     ('rio de janeiro',),
     ('alegre',),
     ('londrina',),
     ('sao paulo',),
     ('senhor do bonfim',),
     ('sao bernardo do campo',),
     ('santana de parnaiba',),
     ('rio de janeiro',),
     ('rio de janeiro',),
     ('piratininga',),
     ('belo horizonte',),
     ('porto alegre',),
     ('maceio',),
     ('duque de caxias',),
     ('florianopolis',),
     ('sao paulo',),
     ('jau',),
     ('sao paulo',),
     ('monte carmelo',),
     ('sao paulo',),
     ('aparecida de goiania',),
     ('atibaia',),
     ('ipiranga',),
     ('belo horizonte',),
     ('taubate',),
     ('sao paulo',),
     ('concordia',),
     ('belo horizonte',),
     ('rio de janeiro',),
     ('jacarei',),
     ('picos',),
     ('una',),
     ('salvador',),
     ('taguai',),
     ('ribeirao preto',),
     ('belo horizonte',),
     ('guarulhos',),
     ('sao paulo',),
     ('peabiru',),
     ('sao paulo',),
     ('sao paulo',),
     ('carangola',),
     ('marilia',),
     ('conquista',),
     ('cabo frio',),
     ('bicas',),
     ('forquilha',),
     ('macae',),
     ('brasilia',),
     ('canoas',),
     ('guaicara',),
     ('campinas',),
     ('santa vitoria',),
     ('sao paulo',),
     ('adamantina',),
     ('franco da rocha',),
     ('salvador',),
     ('sao paulo',),
     ('rio de janeiro',),
     ('sao paulo',),
     ('sao roque',),
     ('franco da rocha',),
     ('manaus',),
     ('rio claro',),
     ('vila velha',),
     ('sao jose de uba',),
     ('ribeirao preto',),
     ('mogi das cruzes',),
     ('sao paulo',),
     ('araras',),
     ('goiania',),
     ('sorriso',),
     ('sao paulo',),
     ('rio de janeiro',),
     ('joinville',),
     ('sao paulo',),
     ('vila velha',),
     ('lages',),
     ('niteroi',),
     ('aracaju',),
     ('nova iguacu',),
     ('sao bernardo do campo',),
     ('sao paulo',),
     ('pindamonhangaba',),
     ('porto alegre',),
     ('valinhos',),
     ('pindamonhangaba',),
     ('fortaleza',),
     ('conselheiro lafaiete',),
     ('rio de janeiro',),
     ('nova iguacu',),
     ('sao paulo',),
     ('rio de janeiro',),
     ('sao bernardo do campo',),
     ('belo horizonte',),
     ('ipatinga',),
     ('sao bernardo do campo',),
     ('guarapuava',),
     ('sao paulo',),
     ('campinas',),
     ('taguatinga',),
     ('tiangua',),
     ('itajuba',),
     ('rio de janeiro',),
     ('paranaiba',),
     ('goiania',),
     ('sorocaba',),
     ('belo horizonte',),
     ('sao paulo',),
     ('david canabarro',),
     ('itarare',),
     ('sao paulo',),
     ('maua',),
     ('curitiba',),
     ('guarulhos',),
     ('maceio',),
     ('cajueiro',),
     ('jacarei',),
     ('florianopolis',),
     ('belo horizonte',),
     ('uberlandia',),
     ('santo andre',),
     ('sao paulo',),
     ('uberlandia',),
     ('cruzeiro',),
     ('fortaleza',),
     ('rio de janeiro',),
     ('aperibe',),
     ('santa cruz do sul',),
     ('sao paulo',),
     ('belo horizonte',),
     ('porto alegre',),
     ('volta redonda',),
     ('presidente epitacio',),
     ('porto alegre',),
     ('belo horizonte',),
     ('joinville',),
     ('vila velha',),
     ('ribeirao pires',),
     ('castanhal',),
     ('belem',),
     ('cacapava',),
     ('nova lima',),
     ('sao paulo',),
     ('cariacica',),
     ('contagem',),
     ('guarapuava',),
     ('sao paulo',),
     ('bom jesus dos perdoes',),
     ('ipatinga',),
     ('urucurituba',),
     ('jandira',),
     ('olinda',),
     ...]



# Count the number of orders placed in 2017.


```python
# SQL query to count orders in 2017
query = """
SELECT COUNT(*) AS total_orders
FROM orders
WHERE LEFT(CAST(order_purchase_timestamp AS VARCHAR(50)), 4) = '2017'
"""

# Execute the query
cur.execute(query)

# Fetch the result
total_orders_2017 = cur.fetchone()[0]

# Print the output
print(total_orders_2017)
```

    180404
    

# Find the total sales per category.


```python
query = """
SELECT 
    products.product_category AS category,
    ROUND(SUM(payments.payment_value), 2) AS total_payment
FROM products
JOIN order_items 
    ON products.product_id = order_items.product_id
JOIN payments 
    ON order_items.order_id = payments.order_id
GROUP BY products.product_category
ORDER BY category ASC;
"""
cur.execute(query)
data = cur.fetchall()
# Convert directly to DataFrame
df = pd.DataFrame([tuple(row) for row in data], columns=["category", "total_payment"])

# Optional: make sure customer_id is integer
df['total_payment'] = df['total_payment'].astype(float)

df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>category</th>
      <th>total_payment</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>None</td>
      <td>2022413.68</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Agro Industria e Comercio</td>
      <td>949844.88</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Art</td>
      <td>247943.44</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Arts and Crafts</td>
      <td>18609.36</td>
    </tr>
    <tr>
      <th>4</th>
      <td>audio</td>
      <td>482596.96</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>69</th>
      <td>stationary store</td>
      <td>2539520.56</td>
    </tr>
    <tr>
      <th>70</th>
      <td>technical books</td>
      <td>199323.52</td>
    </tr>
    <tr>
      <th>71</th>
      <td>telephony</td>
      <td>3895056.40</td>
    </tr>
    <tr>
      <th>72</th>
      <td>toys</td>
      <td>4952301.52</td>
    </tr>
    <tr>
      <th>73</th>
      <td>Watches present</td>
      <td>11433733.44</td>
    </tr>
  </tbody>
</table>
<p>74 rows × 2 columns</p>
</div>



# Calculate the percentage of orders that were paid in installments.


```python
query = """SELECT 
    CAST(SUM(CASE WHEN payment_installments >= 1 THEN 1 ELSE 0 END) AS FLOAT)/ COUNT(*) *100
    AS ratio
FROM payments;
"""
cur.execute(query)
data = cur.fetchall()
print("The percentage of orders that were paid in intstallments is", data[0][0])

```

    The percentage of orders that were paid in intstallments is 99.99807481277554
    

# Count the number of customers from each state. 


```python
query = """
SELECT 
    customer_state AS state,
    COUNT(customer_id) AS customer_count
FROM customers
GROUP BY customer_state
ORDER BY customer_count DESC;
"""
cur.execute(query)
data= cur.fetchall()

# Convert directly to DataFrame
df = pd.DataFrame([tuple(column) for column in data], columns=["state", "customer_count"])

# Optional: make sure customer_id is integer
df['customer_count'] = df['customer_count'].astype(int)

df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>state</th>
      <th>customer_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>SP</td>
      <td>166984</td>
    </tr>
    <tr>
      <th>1</th>
      <td>RJ</td>
      <td>51408</td>
    </tr>
    <tr>
      <th>2</th>
      <td>MG</td>
      <td>46540</td>
    </tr>
    <tr>
      <th>3</th>
      <td>RS</td>
      <td>21864</td>
    </tr>
    <tr>
      <th>4</th>
      <td>PR</td>
      <td>20180</td>
    </tr>
    <tr>
      <th>5</th>
      <td>SC</td>
      <td>14548</td>
    </tr>
    <tr>
      <th>6</th>
      <td>BA</td>
      <td>13520</td>
    </tr>
    <tr>
      <th>7</th>
      <td>DF</td>
      <td>8560</td>
    </tr>
    <tr>
      <th>8</th>
      <td>ES</td>
      <td>8132</td>
    </tr>
    <tr>
      <th>9</th>
      <td>GO</td>
      <td>8080</td>
    </tr>
    <tr>
      <th>10</th>
      <td>PE</td>
      <td>6608</td>
    </tr>
    <tr>
      <th>11</th>
      <td>CE</td>
      <td>5344</td>
    </tr>
    <tr>
      <th>12</th>
      <td>PA</td>
      <td>3900</td>
    </tr>
    <tr>
      <th>13</th>
      <td>MT</td>
      <td>3628</td>
    </tr>
    <tr>
      <th>14</th>
      <td>MA</td>
      <td>2988</td>
    </tr>
    <tr>
      <th>15</th>
      <td>MS</td>
      <td>2860</td>
    </tr>
    <tr>
      <th>16</th>
      <td>PB</td>
      <td>2144</td>
    </tr>
    <tr>
      <th>17</th>
      <td>PI</td>
      <td>1980</td>
    </tr>
    <tr>
      <th>18</th>
      <td>RN</td>
      <td>1940</td>
    </tr>
    <tr>
      <th>19</th>
      <td>AL</td>
      <td>1652</td>
    </tr>
    <tr>
      <th>20</th>
      <td>SE</td>
      <td>1400</td>
    </tr>
    <tr>
      <th>21</th>
      <td>TO</td>
      <td>1120</td>
    </tr>
    <tr>
      <th>22</th>
      <td>RO</td>
      <td>1012</td>
    </tr>
    <tr>
      <th>23</th>
      <td>AM</td>
      <td>592</td>
    </tr>
    <tr>
      <th>24</th>
      <td>AC</td>
      <td>324</td>
    </tr>
    <tr>
      <th>25</th>
      <td>AP</td>
      <td>272</td>
    </tr>
    <tr>
      <th>26</th>
      <td>RR</td>
      <td>184</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.bar(df["state"],df["customer_count"])
plt.xticks(rotation = 90)
plt.show()
```


    
![png](output_12_0.png)
    


# Calculate the number of orders per month in 2018.


```python
query = """ SELECT 
    DATENAME(MONTH, TRY_CAST(CAST(order_purchase_timestamp AS varchar(50)) AS datetime)) AS MonthName,
    COUNT(CAST(order_id AS varchar(50))) AS Counts
FROM orders
WHERE YEAR(TRY_CAST(CAST(order_purchase_timestamp AS varchar(50)) AS datetime)) = 2018
GROUP BY 
    DATENAME(MONTH, TRY_CAST(CAST(order_purchase_timestamp AS varchar(50)) AS datetime)),
    MONTH(TRY_CAST(CAST(order_purchase_timestamp AS varchar(50)) AS datetime))
ORDER BY 
    MONTH(TRY_CAST(CAST(order_purchase_timestamp AS varchar(50)) AS datetime))"""
cur.execute(query)
data= cur.fetchall()
df = pd.DataFrame([tuple(column) for column in data], columns=["MonthName", "Counts"])

# Optional: make sure customer_id is integer
df['Counts'] = df['Counts'].astype(int)


df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MonthName</th>
      <th>Counts</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>January</td>
      <td>29076</td>
    </tr>
    <tr>
      <th>1</th>
      <td>February</td>
      <td>26912</td>
    </tr>
    <tr>
      <th>2</th>
      <td>March</td>
      <td>28844</td>
    </tr>
    <tr>
      <th>3</th>
      <td>April</td>
      <td>27756</td>
    </tr>
    <tr>
      <th>4</th>
      <td>May</td>
      <td>27492</td>
    </tr>
    <tr>
      <th>5</th>
      <td>June</td>
      <td>24668</td>
    </tr>
    <tr>
      <th>6</th>
      <td>July</td>
      <td>25168</td>
    </tr>
    <tr>
      <th>7</th>
      <td>August</td>
      <td>26048</td>
    </tr>
    <tr>
      <th>8</th>
      <td>September</td>
      <td>64</td>
    </tr>
    <tr>
      <th>9</th>
      <td>October</td>
      <td>16</td>
    </tr>
  </tbody>
</table>
</div>




```python
ax = sns.barplot(x= df["MonthName"],y = df["Counts"],data=df, hue = df["MonthName"], palette="viridis")
plt.xticks(rotation = 45)
plt.title("total order per month in 2018")
for container in ax.containers:
    ax.bar_label(container)
plt.show()
```


    
![png](output_15_0.png)
    


# Find the average number of products per order, grouped by customer city.


```python
query = """WITH count_per_order AS (
    SELECT 
        CAST(o.order_id AS varchar(50)) AS order_id,
        CAST(o.customer_id AS varchar(50)) AS customer_id,
        COUNT(oi.order_id) AS oc
    FROM orders AS o
    JOIN order_items AS oi
        ON CAST(o.order_id AS varchar(50)) = CAST(oi.order_id AS varchar(50))
    GROUP BY 
        CAST(o.order_id AS varchar(50)),
        CAST(o.customer_id AS varchar(50))
)
SELECT 
    CAST(c.customer_city AS varchar(100)) AS customer_city,
    ROUND(AVG(CAST(cpo.oc AS float)), 2) AS average_orders
FROM customers AS c
JOIN count_per_order AS cpo
    ON CAST(c.customer_id AS varchar(50)) = CAST(cpo.customer_id AS varchar(50))
GROUP BY 
    CAST(c.customer_city AS varchar(100));
"""
cur.execute(query)
data= cur.fetchall()
df = pd.DataFrame([tuple(column) for column in data], columns=["customer_city", "average_products/order"])

# Optional: make sure customer_id is integer
df['average_products/order'] = df['average_products/order'].astype(int)
df.head(10)

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customer_city</th>
      <th>average_products/order</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>claudia</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1</th>
      <td>santa salete</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>sao jose dos cordeiros</td>
      <td>8</td>
    </tr>
    <tr>
      <th>3</th>
      <td>santa izabel do oeste</td>
      <td>8</td>
    </tr>
    <tr>
      <th>4</th>
      <td>andradina</td>
      <td>9</td>
    </tr>
    <tr>
      <th>5</th>
      <td>mostardas</td>
      <td>8</td>
    </tr>
    <tr>
      <th>6</th>
      <td>buritis</td>
      <td>9</td>
    </tr>
    <tr>
      <th>7</th>
      <td>cacule</td>
      <td>10</td>
    </tr>
    <tr>
      <th>8</th>
      <td>santa quiteria</td>
      <td>8</td>
    </tr>
    <tr>
      <th>9</th>
      <td>novo jardim</td>
      <td>8</td>
    </tr>
  </tbody>
</table>
</div>



# Calculate the percentage of total revenue contributed by each product category.


```python
query="""
SELECT 
    products.product_category AS category,
    ROUND((SUM(payments.payment_value)/(select sum(payment_value)from payments))*100, 2)sales
FROM products
JOIN order_items 
    ON products.product_id = order_items.product_id
JOIN payments 
    ON order_items.order_id = payments.order_id
GROUP BY products.product_category
ORDER BY category ASC;
"""
cur.execute(query)
data= cur.fetchall()
df = pd.DataFrame([tuple(column) for column in data], columns=["Category", "Percentage Distribution"])

# Optional: make sure customer_id is integer
df['Percentage Distribution'] = df['Percentage Distribution'].astype(float)
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Category</th>
      <th>Percentage Distribution</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>None</td>
      <td>6.32</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Agro Industria e Comercio</td>
      <td>2.97</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Art</td>
      <td>0.77</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Arts and Crafts</td>
      <td>0.06</td>
    </tr>
    <tr>
      <th>4</th>
      <td>audio</td>
      <td>1.51</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>69</th>
      <td>stationary store</td>
      <td>7.93</td>
    </tr>
    <tr>
      <th>70</th>
      <td>technical books</td>
      <td>0.62</td>
    </tr>
    <tr>
      <th>71</th>
      <td>telephony</td>
      <td>12.17</td>
    </tr>
    <tr>
      <th>72</th>
      <td>toys</td>
      <td>15.47</td>
    </tr>
    <tr>
      <th>73</th>
      <td>Watches present</td>
      <td>35.71</td>
    </tr>
  </tbody>
</table>
<p>74 rows × 2 columns</p>
</div>



# Identify the correlation between product price and the number of times a product has been purchased.


```python
import numpy as np
query = """
select products.product_category,
COUNT(order_items.product_id) As order_count,
round(avg(order_items.price),2) As Price
from products join order_items
on order_items.product_id = products.product_id
group by products.product_category
order by order_count desc
"""
cur.execute(query)
data= cur.fetchall()
df = pd.DataFrame([tuple(column) for column in data], columns=["Category", "Order_Count","Price"])

# Optional: make sure customer_id is integer
df['Price'] = df['Price'].astype(float)

arr1 =df["Order_Count"]
arr2 = df["Price"]

a = np.corrcoef([arr1, arr2])
print("The Correlation between product price & number of times order purchased is", a[0][1])
```

    The Correlation between product price & number of times order purchased is -0.10631514167157564
    

# Calculate the total revenue generated by each seller, and rank them by revenue


```python
query = """select *, dense_rank() over(order by revenue desc) as rn
from (select order_items.seller_id,
SUM(payments.payment_value) revenue
from order_items join payments
on order_items.order_id = payments.order_id
group by order_items.seller_id) as a
"""
cur.execute(query)
data= cur.fetchall()
df = pd.DataFrame([tuple(column) for column in data], columns=["Seller_id", "revenue","rank"])

# Optional: make sure customer_id is integer
df['rank'] = df['rank'].astype(int)
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Seller_id</th>
      <th>revenue</th>
      <th>rank</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7c67e1448b00f6e969d365cea6b010ab</td>
      <td>2028667.64</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1025f0e2d44d7041d6cf58b6550e0bfa</td>
      <td>1232888.16</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4a3ca9315b744ce9f8e9374361493884</td>
      <td>1204981.08</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1f50f920176fa81dab994f9023523100</td>
      <td>1161013.68</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>53243585a1d6dc2643021fd1853d8905</td>
      <td>1139612.32</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
dframe = df.head()
ax = sns.barplot(x='Seller_id',y='revenue', data=dframe)
plt.xticks(rotation = 90)
for container in ax.containers:
    ax.bar_label(container)
plt.show()
```


    
![png](output_24_0.png)
    



```python

```
